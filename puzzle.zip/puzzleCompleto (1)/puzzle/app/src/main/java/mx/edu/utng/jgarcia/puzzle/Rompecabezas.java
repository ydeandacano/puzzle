package mx.edu.utng.ydeanda.puzzle;

public class Rompecabezas {
    private int disponible=16;
    int[] tablero= new int[16];

    public Rompecabezas(){
        for(int i=0;i<16;i++){
            tablero[i]=i;
        }
    }

    public boolean verificarGan(){
        boolean banGan= true;
        for(int i=0;i<16;i++){
            if(tablero[i]!=i){
                banGan= false;
                break;
            }
        }
        return banGan;
    }





    public void mover(int pos, int dxy){
        int x= pos/4;
        int y= pos%4;
        int tempo=0;
        switch(dxy){
            case 1: //arriba
                tempo=tablero[y];
                tablero[y]=tablero[y+4];
                tablero[y+4]=tablero[y+8];
                tablero[y+8]=tablero[y+12];
                tablero[y+12]=tempo;
                break;
            case 2: //derecha
                tempo=tablero[x*4+3];
                tablero[x*4+3]=tablero[x*4+2];
                tablero[x*4+2]=tablero[x*4+1];
                tablero[x*4+1]=tablero[x*4];
                tablero[x*4]=tempo;
                break;
            case 3: //abajo
                tempo=tablero[y+12];
                tablero[y+12]=tablero[y+8];
                tablero[y+8]=tablero[y+4];
                tablero[y+4]=tablero[y];
                tablero[y]=tempo;
                break;
            case 4: //izquierda
                tempo=tablero[x*4];
                tablero[x*4]=tablero[x*4+1];
                tablero[x*4+1]=tablero[x*4+2];
                tablero[x*4+2]=tablero[x*4+3];
                tablero[x*4+3]=tempo;
                break;
        }
    }
}

