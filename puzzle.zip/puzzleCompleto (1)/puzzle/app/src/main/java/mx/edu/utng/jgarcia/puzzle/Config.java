package mx.edu.utng.ydeanda.puzzle;

public class Config {
    public static final String URL_ADD="http://192.168.1.111:8081/Android/Puzzle/addUsu.php";
    public static final String URL_GET_ALL= "http://192.168.1.111:8081/Android/Puzzle/getAllUsu.php";


    //Definiendo las constants para ser usadas en los requerimientos a los scripts de PHP
    public static final String KEY_USU_ID = "id";
    public static final String KEY_USU_NOMBRE = "nombre";
    public static final String KEY_USU_MOVIMIENTOS = "movimientos";
    public static final String KEY_USU_TIEMPO = "tiempo";

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NOMBRE = "nombre";
    public static final String TAG_MOVIMIENTOS = "movimientos";
    public static final String TAG_TIEMPO = "tiempo";

    public static final String EMP_ID = "emp_id";
}
