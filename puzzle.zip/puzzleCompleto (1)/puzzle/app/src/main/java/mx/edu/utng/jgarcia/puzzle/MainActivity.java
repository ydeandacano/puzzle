﻿package mx.edu.utng.ydeanda.puzzle;

import java.security.Principal;
import java.util.HashMap;
import java.util.Random;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.os.SystemClock;
import android.support.v4.app.DialogFragment;
import android.text.format.Time;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener, OnTouchListener, OnItemSelectedListener, CuadroDialogo.FinalizoCuadroDialogo {
    private ImageButton[] tablero= new ImageButton[16];
    private Spinner spnOpcion;
    private Button btnMezclar;
    private Button btnSalir, btnEnviar, btnVisualizar;
    private ImageButton btnTempo;
    private Rompecabezas juego;
    private float x1;
    private float y1;
    private TextView txthora, txt_mov;
    private float numero, acumulador=0, contador=0, l=0;
    private Chronometer crono;
    Context contexx;
    TextView usuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contexx = this;

        usuario = (TextView) findViewById(R.id.txt_usuario);
        juego= new Rompecabezas();
        inicializarControles();


        //Bloquear movimiento
        for (int i=0; i>16; i++){
            tablero[i].setEnabled(true);
        }
        //Mostrar hora
        Time time = new Time();
        time.setToNow();
        txthora = (TextView)findViewById(R.id.txt_hora);
        txthora.setText("Time: " +time.hour + ":" + time.minute + ":" + time.second);
        txt_mov = (TextView) findViewById(R.id.txt_movimiento);
        txt_mov.setText(""+acumulador);
        crono = (Chronometer) findViewById(R.id.fda);


    }
    private void addEmployee(){

        final String nombre = usuario.getText().toString().trim();
        final String movimientos = txt_mov.getText().toString().trim();
        final String tiempo = crono.getText().toString().trim();

        class AddEmployee extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(MainActivity.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(MainActivity.this,s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... v
            ) {
                HashMap<String,String> params = new HashMap<>();
                params.put(Config.KEY_USU_NOMBRE,nombre);
                params.put(Config.KEY_USU_MOVIMIENTOS,movimientos);
                params.put(Config.KEY_USU_TIEMPO,tiempo);

                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD, params);
                return res;
            }
        }

        AddEmployee ae = new AddEmployee();
        ae.execute();
    }







    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub

        switch(v.getId()){
            case R.id.btn_mezclar:
                mezclar();
                crono.setBase(SystemClock.elapsedRealtime());
                new CuadroDialogo(contexx, MainActivity.this);
                crono.start();
                break;
            case R.id.btn_salir:
                System.exit(0);
                break;

            case R.id.enviar:
                if(v.getId() == R.id.enviar){
                    addEmployee();
                }

            case R.id.btnvisualizar:
                if(v.getId() == R.id.btnvisualizar){
                    startActivity(new Intent(this,ViewAllUsuarios.class));
                }




        }
    }

    private void inicializarControles(){
        btnTempo= new ImageButton(this);
        tablero[0]=(ImageButton)findViewById(R.id.button1);
        tablero[1]=(ImageButton)findViewById(R.id.button2);
        tablero[2]=(ImageButton)findViewById(R.id.button3);
        tablero[3]=(ImageButton)findViewById(R.id.button4);
        tablero[4]=(ImageButton)findViewById(R.id.button5);
        tablero[5]=(ImageButton)findViewById(R.id.button6);
        tablero[6]=(ImageButton)findViewById(R.id.button7);
        tablero[7]=(ImageButton)findViewById(R.id.button8);
        tablero[8]=(ImageButton)findViewById(R.id.button9);
        tablero[9]=(ImageButton)findViewById(R.id.button10);
        tablero[10]=(ImageButton)findViewById(R.id.button11);
        tablero[11]=(ImageButton)findViewById(R.id.button12);
        tablero[12]=(ImageButton)findViewById(R.id.button13);
        tablero[13]=(ImageButton)findViewById(R.id.button14);
        tablero[14]=(ImageButton)findViewById(R.id.button15);
        tablero[15]=(ImageButton)findViewById(R.id.button16);

        btnMezclar=(Button)findViewById(R.id.btn_mezclar);
        btnSalir=(Button)findViewById(R.id.btn_salir);
        spnOpcion= (Spinner)findViewById(R.id.spn_opciones);
        btnEnviar = (Button)findViewById(R.id.enviar);
        btnMezclar.setOnClickListener(this);
        btnSalir.setOnClickListener(this);
        btnEnviar.setOnClickListener(this);
        spnOpcion.setOnItemSelectedListener(this);
        btnVisualizar = (Button) findViewById(R.id.btnvisualizar);

        //Setting listeners to button

        btnVisualizar.setOnClickListener(this);

        for(int i=0;i<16;i++){
            tablero[i].setOnTouchListener(this);
        }
    }

    private void mostrarImagen(int pos){
        switch(pos){
            case 0:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.n1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.n2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.n3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.n4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.n5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.n6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.n7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.n8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.n9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.n10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.n11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.n12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.n13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.n14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.n15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.n16));
                break;
            case 1:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.a1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.a2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.a3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.a4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.a5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.a6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.a7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.a8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.a9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.a10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.a11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.a12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.a13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.a14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.a15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.a16));
                break;
            case 2:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.m1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.m2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.m3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.m4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.m5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.m6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.m7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.m8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.m9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.m10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.m11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.m12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.m13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.m14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.m15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.m16));
                break;
            case 3:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.p1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.p2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.p3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.p4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.p5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.p6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.p7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.p8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.p9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.p10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.p11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.p12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.p13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.p14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.p15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.p16));
                break;
            case 4:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.s1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.s2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.s3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.s4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.s5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.s6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.s7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.s8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.s9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.s10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.s11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.s12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.s13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.s14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.s15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.s16));
                break;
            case 5:
                tablero[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.f1));
                tablero[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.f2));
                tablero[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.f3));
                tablero[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.f4));
                tablero[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.f5));
                tablero[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.f6));
                tablero[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.f7));
                tablero[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.f8));
                tablero[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.f9));
                tablero[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.f10));
                tablero[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.f11));
                tablero[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.f12));
                tablero[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.f13));
                tablero[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.f14));
                tablero[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.f15));
                tablero[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.f16));
                break;
        }
        juego= new Rompecabezas();
    }

    private void mezclar(){
        Random r1= new Random();
        int pos=0;
        int dxy=0;

        for(int i=1;i<=100;i++){
            pos= r1.nextInt(16);
            dxy= r1.nextInt(4)+1;
            juego.mover(pos, dxy);
            moverPieza(pos,dxy);



        }
        //Bloquear movimiento
        for (int i=0; i>16; i++){
            tablero[i].setEnabled(false);
        }
    }

    private void moverPieza(int pos,int dxy){
        int x= pos/4;
        int y= pos%4;
        System.out.println("moviendo pieza...");



        switch(dxy){
            case 1: //arriba
                btnTempo.setBackgroundDrawable(tablero[y].getBackground());
                tablero[y].setBackgroundDrawable(tablero[y+4].getBackground());
                tablero[y+4].setBackgroundDrawable(tablero[y+8].getBackground());
                tablero[y+8].setBackgroundDrawable(tablero[y+12].getBackground());
                tablero[y+12].setBackgroundDrawable(btnTempo.getBackground());
                break;
            case 2: //derecha
                btnTempo.setBackgroundDrawable(tablero[x*4+3].getBackground());
                tablero[x*4+3].setBackgroundDrawable(tablero[x*4+2].getBackground());
                tablero[x*4+2].setBackgroundDrawable(tablero[x*4+1].getBackground());
                tablero[x*4+1].setBackgroundDrawable(tablero[x*4].getBackground());
                tablero[x*4].setBackgroundDrawable(btnTempo.getBackground());
                break;
            case 3: //abajo
                btnTempo.setBackgroundDrawable(tablero[y+12].getBackground());
                tablero[y+12].setBackgroundDrawable(tablero[y+8].getBackground());
                tablero[y+8].setBackgroundDrawable(tablero[y+4].getBackground());
                tablero[y+4].setBackgroundDrawable(tablero[y].getBackground());
                tablero[y].setBackgroundDrawable(btnTempo.getBackground());
                break;
            case 4: //izquierda
                btnTempo.setBackgroundDrawable(tablero[x*4].getBackground());
                tablero[x*4].setBackgroundDrawable(tablero[x*4+1].getBackground());
                tablero[x*4+1].setBackgroundDrawable(tablero[x*4+2].getBackground());
                tablero[x*4+2].setBackgroundDrawable(tablero[x*4+3].getBackground());
                tablero[x*4+3].setBackgroundDrawable(btnTempo.getBackground());
                break;
        }

    }

    @Override
    public boolean onTouch(View view, MotionEvent evento) {
        // TODO Auto-generated method stub
        float x2,y2,dx,dy;
        int dxy=0;
        int pos=0;
        boolean banMov=false;

        for(l=1; l<=10; l++)
        {



            acumulador=acumulador+dxy;


        }
        switch(evento.getAction()){
            case (MotionEvent.ACTION_DOWN):
                x1= evento.getX();
                y1= evento.getY();



                break;
            case (MotionEvent.ACTION_UP):
                x2= evento.getX();
                y2= evento.getY();
                dx= x2-x1;
                dy= y2-y1;
                banMov=(Math.abs(dx)>20||Math.abs(dy)>20);

                if(banMov){
                    if(Math.abs(dx)>Math.abs(dy)){
                        if(dx>0){
                            //mover derecha
                            dxy=2;
                        }else{
                            //mover izquierda
                            dxy=4;
                        }
                    }else{
                        if(dy>0){
                            //mover abajo
                            dxy=3;
                        }else{
                            //mover arriba
                            dxy=1;
                        }
                    }

                    break;
                }
        }
        switch(view.getId()){
            case R.id.button1:
                pos=0;
                break;
            case R.id.button2:
                pos=1;
                break;
            case R.id.button3:
                pos=2;
                break;
            case R.id.button4:
                pos=3;
                break;
            case R.id.button5:
                pos=4;
                break;
            case R.id.button6:
                pos=5;
                break;
            case R.id.button7:
                pos=6;
                break;
            case R.id.button8:
                pos=7;
                break;
            case R.id.button9:
                pos=8;
                break;
            case R.id.button10:
                pos=9;
                break;
            case R.id.button11:
                pos=10;
                break;
            case R.id.button12:
                pos=11;
                break;
            case R.id.button13:
                pos=12;
                break;
            case R.id.button14:
                pos=13;
                break;
            case R.id.button15:
                pos=14;
                break;
            case R.id.button16:
                pos=15;
                break;
        }

        if(banMov){
            juego.mover(pos, dxy);//Rompecabezas

            moverPieza(pos, dxy); //Vista


            if(juego.verificarGan()){
                Toast toast= Toast.makeText(this, "¡¡POR FIN Ganaste!!",
                        Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                crono.stop();


            }
        }
        return false;
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {
        // TODO Auto-generated method stub
        int op=0;
        op= (int)spnOpcion.getSelectedItemId();
        mostrarImagen(op);
        //Bloquear movimiento
        for (int i=0; i>16; i++){
            tablero[i].setEnabled(false);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void ResultadoCuadroDialogo(String nombre) {
    usuario.setText(nombre);
    }
}
