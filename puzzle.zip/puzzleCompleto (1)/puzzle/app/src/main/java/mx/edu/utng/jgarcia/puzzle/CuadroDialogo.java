package mx.edu.utng.ydeanda.puzzle;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;

public class CuadroDialogo {

    public interface FinalizoCuadroDialogo{

        void ResultadoCuadroDialogo(String nombre);
    }

    private FinalizoCuadroDialogo interfaz;


    public CuadroDialogo(Context contexx, FinalizoCuadroDialogo actividad){

        interfaz= actividad;
        final Dialog dialogo = new Dialog(contexx);
        dialogo.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogo.setCancelable(false);
        dialogo.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogo.setContentView(R.layout.dialog_signin);

        final EditText nombre = (EditText) dialogo.findViewById(R.id.username);
        ImageView aceptar = (ImageView) dialogo.findViewById(R.id.aceptar);

        nombre.setInputType(InputType.TYPE_CLASS_TEXT);

        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                interfaz.ResultadoCuadroDialogo(nombre.getText().toString());
                dialogo.dismiss();

            }
        });
        dialogo.show();

    }
}
